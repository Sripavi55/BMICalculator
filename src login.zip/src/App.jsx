import Auth from "./Auth";

export default function App() {
  return <Auth />;
}
